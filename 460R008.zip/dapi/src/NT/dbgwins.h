/*
 * Debug Window Source File
 *  Kevin Bruckert  July 11, 1996
 *
 * These function create a virtual "printf" function for WIN95/NT for debugging
 *
 * Used by PH
 */

#define	MAX_LINES		2000
#define	MAX_PER_LINE	128

void WINstart_thread(void);
void WINprintf(char *fmt, ...);
void WINprint(char *str);
