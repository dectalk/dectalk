/*
 ***********************************************************************
 *
 *                           Coryright (c)
 *    � Digital Equipment Corporation 1996, 1997. All rights reserved.
 *
 *    Restricted Rights: Use, duplication, or disclosure by the U.S.
 *    Government is subject to restrictions as set forth in subparagraph
 *    (c) (1) (ii) of DFARS 252.227-7013, or in FAR 52.227-19, or in FAR
 *    52.227-14 Alt. III, as applicable.
 *
 *    This software is proprietary to and embodies the confidential
 *    technology of Digital Equipment Corporation and other parties.
 *    Possession, use, or copying of this software and media is authorized
 *    only pursuant to a valid written license from Digital or an
 *    authorized sublicensor.
 *
 ***********************************************************************
 *    File Name:    lsa_rule.c
 *    Author:       Matthew Schnee
 *    Creation Date:03/27/96
 *
 *    Functionality:
 * 	  Shell to include ls_rule.c for the ACNA compile
 *
 ***********************************************************************
 *    Revision History:                    
 *
 *  Rev Who     Date        	Description
 *  --- -----   ----------- 	---------------------------------------
 *  001 MGS     04/24/1996 		fixed include to be ls_rule.c not ls_task.c                    
 *  002 GL      10/13/1997      For BATS#486 remove English_us only ACNA setting 
 *
 */                         
/*
#ifdef ENGLISH_US
#ifndef ACNA
#define ACNA
#endif
#endif
*/
#include "ls_rule.c"


