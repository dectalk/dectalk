#ifndef  share_defs
#define  share_defs 1

_far putseq();
_far getseq(); 

_far printf();
_far speakf();

#endif
