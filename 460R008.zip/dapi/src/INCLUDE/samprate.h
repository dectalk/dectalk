/**********************************************************************/
/*                                                                    */
/*  Include File: samprate.h                                          */
/*                                                                    */
/*  This include file declares the default sample rates for DECtalk.  */
/*                                                                    */
/**********************************************************************/

#define  PC_SAMPLE_RATE     11025
#define  MULAW_SAMPLE_RATE   8000
